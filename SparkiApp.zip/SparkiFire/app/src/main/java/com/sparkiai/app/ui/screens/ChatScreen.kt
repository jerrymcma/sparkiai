package com.sparkiai.app.ui.screens

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.sparkiai.app.R
import com.sparkiai.app.ui.components.MessageBubble
import com.sparkiai.app.ui.components.PersonalitySelectorDialog
import com.sparkiai.app.ui.theme.*
import com.sparkiai.app.viewmodel.ChatViewModel
import com.sparkiai.app.model.Message
import com.sparkiai.app.model.MessageType
import com.sparkiai.app.utils.VoiceManager
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel = viewModel()
) {
    val context = LocalContext.current
    val voiceManager = remember { VoiceManager(context) }

    // Initialize ViewModel with context for memory management
    LaunchedEffect(Unit) {
        viewModel.initialize(context)
    }

    val messages by viewModel.messages.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val isListening by voiceManager.isListening.collectAsState()
    val isSpeaking by voiceManager.isSpeaking.collectAsState()
    val recognizedText by voiceManager.recognizedText.collectAsState()
    val currentPersonality by viewModel.currentPersonality.collectAsState()
    val availablePersonalities by viewModel.availablePersonalities.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var showImageOptions by remember { mutableStateOf(false) }
    var showPersonalitySelector by remember { mutableStateOf(false) }
    var showStartFreshDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Create a temporary file for camera capture
    val photoFile = remember {
        File(context.cacheDir, "temp_photo_${System.currentTimeMillis()}.jpg")
    }
    val photoUri = remember {
        FileProvider.getUriForFile(context, "${context.packageName}.provider", photoFile)
    }

    // Gallery launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
        showImageOptions = false
    }

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            selectedImageUri = photoUri
        }
        showImageOptions = false
    }

    // Mic/audio permission launcher
    var micPermissionRequested by remember { mutableStateOf(false) }
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            micPermissionRequested = false
            if (granted) {
                voiceManager.startListening()
            }
        }
    )

    // Handle recognized speech
    LaunchedEffect(recognizedText) {
        if (recognizedText.isNotEmpty()) {
            messageText = recognizedText
            voiceManager.clearRecognizedText()
        }
    }

    // Auto scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            coroutineScope.launch {
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    // Clean up voice manager
    DisposableEffect(Unit) {
        onDispose {
            voiceManager.destroy()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        // Custom App Bar Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.White,
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left side - current personality heading
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Text(
                        text = currentPersonality.name,
                        fontWeight = FontWeight.Bold,
                        color = TextOnAIMessage,
                        fontSize = 20.sp
                    )
                    if (isSpeaking) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speaking",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Right side - Personalities Button inline with text and sparkles
                TextButton(
                    onClick = { showPersonalitySelector = true },
                    modifier = Modifier.padding(end = 2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Personalities",
                            fontSize = 13.sp,
                            color = TextOnAIMessage,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "✨",
                            fontSize = 20.sp
                        )
                    }
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    WelcomeMessage(currentPersonality.name, currentPersonality.greeting)
                }
            } else {
                items(messages) { message ->
                    MessageBubble(
                        message = message,
                        onSpeakClick = { text ->
                            voiceManager.speak(text)
                        }
                    )
                }
            }

            if (isLoading) {
                item {
                    TypingIndicator()
                }
            }
        }

        // Message Input with Voice and Image Controls
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .imePadding(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(8.dp)
            ) {
                // Selected Image Preview
                selectedImageUri?.let { uri ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(uri)
                                .build(),
                            contentDescription = "Selected image",
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "Image selected",
                            modifier = Modifier.weight(1f),
                            color = PrimaryBlue,
                            fontSize = 14.sp
                        )

                        IconButton(
                            onClick = { selectedImageUri = null }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove image",
                                tint = Color.Red
                            )
                        }
                    }
                }

                // Voice Status Indicator
                if (isListening) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Listening",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Listening...",
                            color = PrimaryBlue,
                            fontSize = 12.sp
                        )
                    }
                }

                // Text Field - Full Width
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Say hello, ask anything...") },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Default
                    ),
                    keyboardActions = KeyboardActions.Default,
                    minLines = 2,
                    maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = PrimaryBlue,
                        unfocusedTextColor = PrimaryBlue
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Icons Row - Image, Mic, Send, Start Fresh
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Image Input Button
                    IconButton(
                        onClick = { showImageOptions = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Add image",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Voice Input Button
                    IconButton(
                        onClick = {
                            if (isListening) {
                                voiceManager.stopListening()
                            } else {
                                // Check if mic permission is granted
                                val permissionGranted =
                                    androidx.core.content.ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                if (permissionGranted) {
                                    voiceManager.startListening()
                                } else if (!micPermissionRequested) {
                                    micPermissionRequested = true
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = if (isListening) "Stop listening" else "Start voice input",
                            tint = if (isListening) Color.Red else PrimaryBlue,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Send Button
                    FloatingActionButton(
                        onClick = {
                            if ((messageText.isNotBlank() || selectedImageUri != null) && !isLoading) {
                                sendMessage(viewModel, messageText, selectedImageUri)
                                messageText = ""
                                selectedImageUri = null
                                keyboardController?.hide()
                            }
                        },
                        modifier = Modifier.size(48.dp),
                        containerColor = PrimaryBlue,
                        contentColor = Color.White
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send message"
                        )
                    }

                    // Start Fresh Button
                    IconButton(
                        onClick = { showStartFreshDialog = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Start Fresh",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
    }

    // Personality Selector Dialog
    if (showPersonalitySelector) {
        PersonalitySelectorDialog(
            personalities = availablePersonalities,
            currentPersonality = currentPersonality,
            onPersonalitySelected = { personality ->
                viewModel.changePersonality(personality)
            },
            onDismiss = { showPersonalitySelector = false }
        )
    }

    // Start Fresh Dialog
    if (showStartFreshDialog) {
        AlertDialog(
            onDismissRequest = { showStartFreshDialog = false },
            title = { Text("Start Fresh") },
            text = { Text("Start over? AI will forget this chat.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showStartFreshDialog = false
                        viewModel.startFresh()
                    }
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStartFreshDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Image Options Dialog
    if (showImageOptions) {
        AlertDialog(
            onDismissRequest = { showImageOptions = false },
            title = { Text("Add Image") },
            text = { Text("Choose how to add an image to your message") },
            confirmButton = {
                Row {
                    TextButton(
                        onClick = {
                            cameraLauncher.launch(photoUri)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Camera")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    TextButton(
                        onClick = {
                            galleryLauncher.launch("image/*")
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Gallery")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showImageOptions = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun sendMessage(viewModel: ChatViewModel, text: String, imageUri: Uri?) {
    when {
        imageUri != null && text.isNotBlank() -> {
            // Text with image
            viewModel.sendMessage(
                content = text,
                imageUri = imageUri.toString(),
                messageType = MessageType.TEXT_WITH_IMAGE
            )
        }
        imageUri != null -> {
            // Image only
            viewModel.sendMessage(
                content = "📷 Image shared",
                imageUri = imageUri.toString(),
                messageType = MessageType.IMAGE
            )
        }
        text.isNotBlank() -> {
            // Text only
            viewModel.sendMessage(text)
        }
    }
}

@Composable
fun WelcomeMessage(
    personalityName: String = "SparkiFire AI",
    greeting: String = "Hello! I'm SparkiFire AI, your intelligent assistant."
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = AIMessageBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Welcome! 🔥",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextOnAIMessage
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = greeting,
                fontSize = 16.sp,
                color = TextOnAIMessage
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "You can type, use voice input, or share images. Tap the person icon to change my personality!",
                fontSize = 14.sp,
                color = TextOnAIMessage.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "sparkle-pulse")
    val flameSequenceProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 450, easing = LinearEasing)
        ),
        label = "flame-sequence"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = AIMessageBackground),
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sparki is thinking",
                    color = TextOnAIMessage,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val offsets = listOf(0f, 1f / 3f, 2f / 3f)
                    offsets.forEachIndexed { index, offset ->
                        val phase = (flameSequenceProgress - offset + 1f) % 1f
                        val isActive = phase < 1f / 3f
                        Icon(
                            painter = painterResource(id = R.drawable.flameicon),
                            contentDescription = null,
                            tint = PrimaryBlue.copy(alpha = if (isActive) 1f else 0.2f),
                            modifier = Modifier.size(24.dp)
                        )
                        if (index < offsets.lastIndex) {
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                    }
                }
            }
        }
    }
}