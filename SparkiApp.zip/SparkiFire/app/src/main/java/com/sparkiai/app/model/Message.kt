package com.sparkiai.app.model

data class Message(
    val id: String = java.util.UUID.randomUUID().toString(),
    val content: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUri: String? = null,
    val messageType: MessageType = MessageType.TEXT,
    val personalityId: String? = null // Track which personality this message belongs to
)

enum class MessageType {
    TEXT,
    IMAGE,
    TEXT_WITH_IMAGE
}