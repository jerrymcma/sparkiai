package com.sparkiai.app.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sparkiai.app.model.AIPersonalities
import com.sparkiai.app.model.AIPersonality
import com.sparkiai.app.model.Message
import com.sparkiai.app.model.MessageType
import com.sparkiai.app.repository.AIRepository
import com.sparkiai.app.utils.ChatMemoryManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel(
    private val aiRepository: AIRepository = AIRepository(),
    private var memoryManager: ChatMemoryManager? = null
) : ViewModel() {

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _shouldSpeakResponse = MutableStateFlow(false)
    val shouldSpeakResponse: StateFlow<Boolean> = _shouldSpeakResponse.asStateFlow()

    private val _lastAIResponse = MutableStateFlow("")
    val lastAIResponse: StateFlow<String> = _lastAIResponse.asStateFlow()

    private val _currentPersonality = MutableStateFlow(AIPersonalities.DEFAULT)
    val currentPersonality: StateFlow<AIPersonality> = _currentPersonality.asStateFlow()

    private val _availablePersonalities = MutableStateFlow(AIPersonalities.getAllPersonalities())
    val availablePersonalities: StateFlow<List<AIPersonality>> =
        _availablePersonalities.asStateFlow()

    /**
     * Initialize the ChatViewModel with a context for memory management
     */
    fun initialize(context: Context) {
        if (memoryManager == null) {
            memoryManager = ChatMemoryManager(context)
            // Load messages for the current personality
            loadMessagesForCurrentPersonality()
        }
    }

    /**
     * Load messages for the current personality from persistent storage
     */
    private fun loadMessagesForCurrentPersonality() {
        memoryManager?.let { manager ->
            val savedMessages = manager.loadMessages(_currentPersonality.value.id)
            _messages.value = savedMessages
        }
    }

    /**
     * Save current messages to persistent storage
     */
    private fun saveMessages() {
        memoryManager?.let { manager ->
            manager.saveMessages(_currentPersonality.value.id, _messages.value)
        }
    }

    /**
     * Check if we need to auto-reset and handle it
     */
    private fun handleAutoResetIfNeeded() {
        memoryManager?.let { manager ->
            if (manager.shouldAutoReset(_currentPersonality.value.id)) {
                // Clear messages and add auto-reset message
                manager.clearMessages(_currentPersonality.value.id)
                val autoResetMessage = Message(
                    content = ChatMemoryManager.AUTO_RESET_MESSAGE,
                    isFromUser = false,
                    personalityId = _currentPersonality.value.id
                )
                _messages.value = listOf(autoResetMessage)
                saveMessages()
            }
        }
    }

    fun sendMessage(
        content: String,
        shouldSpeak: Boolean = false,
        imageUri: String? = null,
        messageType: MessageType = MessageType.TEXT
    ) {
        if ((content.isBlank() && imageUri == null) || _isLoading.value) return

        // Check for auto-reset before adding new message
        handleAutoResetIfNeeded()

        // Add user message
        val userMessage = Message(
            content = content,
            isFromUser = true,
            imageUri = imageUri,
            messageType = messageType,
            personalityId = _currentPersonality.value.id
        )
        _messages.value = _messages.value + userMessage
        saveMessages() // Save after adding user message

        // Set voice response preference
        _shouldSpeakResponse.value = shouldSpeak

        // Get conversation context for AI
        val conversationContext =
            memoryManager?.getConversationContext(_currentPersonality.value.id) ?: emptyList()

        // Get AI response
        val aiInputContent = augmentUserMessage(content)

        _isLoading.value = true
        viewModelScope.launch {
            try {
                val aiResponse = when (messageType) {
                    MessageType.IMAGE -> aiRepository.getImageAnalysisResponse(
                        aiInputContent,
                        imageUri,
                        _currentPersonality.value,
                        conversationContext
                    )

                    MessageType.TEXT_WITH_IMAGE -> aiRepository.getImageAnalysisResponse(
                        aiInputContent,
                        imageUri,
                        _currentPersonality.value,
                        conversationContext
                    )

                    else -> aiRepository.getAIResponse(
                        aiInputContent,
                        _currentPersonality.value,
                        conversationContext
                    )
                }

                val aiMessage = Message(
                    content = aiResponse,
                    isFromUser = false,
                    personalityId = _currentPersonality.value.id
                )
                _messages.value = _messages.value + aiMessage
                saveMessages() // Save after adding AI response

                // Store last AI response for voice output
                _lastAIResponse.value = aiResponse
            } catch (e: Exception) {
                val errorMessage = Message(
                    content = "Sorry, I encountered an error while processing your request. Please try again.",
                    isFromUser = false,
                    personalityId = _currentPersonality.value.id
                )
                _messages.value = _messages.value + errorMessage
                saveMessages() // Save error message
                _lastAIResponse.value = errorMessage.content
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun changePersonality(personality: AIPersonality) {
        // Save current conversation before switching
        saveMessages()

        _currentPersonality.value = personality

        // Load conversation history for the new personality
        loadMessagesForCurrentPersonality()

        // Add a system message about the personality change only if there are no messages
        if (_messages.value.isEmpty()) {
            val personalityChangeMessage = Message(
                content = personality.greeting,
                isFromUser = false,
                personalityId = personality.id
            )
            _messages.value = _messages.value + personalityChangeMessage
            saveMessages()
        }
    }

    fun getPersonalityGreeting(): String {
        return _currentPersonality.value.greeting
    }

    fun clearShouldSpeak() {
        _shouldSpeakResponse.value = false
    }

    fun clearMessages() {
        _messages.value = emptyList()
        saveMessages() // Save the cleared state
    }

    /**
     * Clear messages for the current personality only
     */
    fun clearCurrentPersonalityMemory() {
        memoryManager?.clearMessages(_currentPersonality.value.id)
        _messages.value = emptyList()
    }

    /**
     * Clear all messages for all personalities
     */
    fun clearAllPersonalitiesMemory() {
        memoryManager?.clearAllMessages()
        _messages.value = emptyList()
    }

    /**
     * Get message count for current personality
     */
    fun getCurrentPersonalityMessageCount(): Int {
        return memoryManager?.getMessageCount(_currentPersonality.value.id) ?: 0
    }

    /**
     * Check if current personality has history
     */
    fun currentPersonalityHasHistory(): Boolean {
        return memoryManager?.hasHistory(_currentPersonality.value.id) ?: false
    }

    /**
     * Start a fresh conversation for the current personality
     */
    fun startFresh() {
        memoryManager?.clearMessages(_currentPersonality.value.id)
        val greetingMessage = Message(
            content = _currentPersonality.value.greeting,
            isFromUser = false,
            personalityId = _currentPersonality.value.id
        )
        _messages.value = listOf(greetingMessage)
        saveMessages()
    }

    override fun onCleared() {
        super.onCleared()
        // Save messages when ViewModel is cleared
        saveMessages()
    }

    private fun augmentUserMessage(originalInput: String): String {
        val lastAssistantMessage = _messages.value.lastOrNull { !it.isFromUser }?.content
            ?: return originalInput

        val normalizedInput = originalInput.lowercase()

        if (normalizedInput.contains("vice president")) {
            val trumpMentionsCurrent = Regex(
                "donald\\s+trump[^.]*current\\s+president",
                RegexOption.IGNORE_CASE
            ).containsMatchIn(lastAssistantMessage)

            if (trumpMentionsCurrent) {
                return buildString {
                    append(
                        "Context anchor: You previously confirmed that Donald Trump is the current President of the United States as of January 20, 2025. " +
                                "The user is still talking about that exact administration. Answer the question using 2025 data and provide the Vice President serving with Donald Trump right now. " +
                                "Do not mention past administrations or older vice presidents.\n\n"
                    )
                    append("User question: ")
                    append(originalInput)
                }
            }
        }

        if (normalizedInput.contains("poem") || normalizedInput.contains("stanza")) {
            val stanzaMatch = Regex("(\\d+)\\s*(stanza|verse)").find(normalizedInput)
            val lineMatch = Regex("(\\d+)\\s*(line|lines)").findAll(normalizedInput).toList()

            val stanzaCount = stanzaMatch?.groups?.get(1)?.value
            val linesPerStanza = lineMatch.getOrNull(0)?.groups?.get(1)?.value

            return buildString {
                append("Follow the exact formatting requested for this poem. ")
                append("If the user asked for specific stanza or line counts, obey them precisely. ")
                append("Insert explicit newline characters between every line and keep a blank line between stanzas. ")
                stanzaCount?.let {
                    append("Output exactly $it stanza(s). ")
                }
                linesPerStanza?.let {
                    append("Each stanza must contain exactly $it line(s). ")
                }
                append("Never merge lines into paragraphs.")
                append("\n\nUser request: ")
                append(originalInput)
            }
        }

        return originalInput
    }
}