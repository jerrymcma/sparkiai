import axios from 'axios';
import { AIPersonality, ResponseStyle, ConversationPair } from '../types';

class GeminiService {
  private apiKey: string;
  private baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models';

  constructor() {
    this.apiKey = import.meta.env.VITE_GEMINI_API_KEY || '';
  }

  isConfigured(): boolean {
    return this.apiKey.length > 0;
  }

  async generateResponse(
    userMessage: string,
    personality: AIPersonality | null,
    conversationContext: ConversationPair[] = []
  ): Promise<string> {
    try {
      if (!this.isConfigured()) {
        return '⚙️ Real AI not configured yet. Please add your Gemini API key to use real AI responses!';
      }

      const systemPrompt = this.buildPersonalityPrompt(personality);
      const conversationHistory = this.buildConversationHistory(conversationContext);
      const fullPrompt = `${systemPrompt}\n\n${conversationHistory}\nUser: ${userMessage}\nAssistant:`;

      // Always-on grounding mode
      const needsSearch = true;

      console.log('Grounding enabled (always-on mode) for query:', userMessage);

      const requestBody = {
        contents: [
          {
            parts: [
              {
                text: fullPrompt
              }
            ]
          }
        ],
        ...(needsSearch && {
          tools: [
            {
              google_search: {}
            }
          ]
        }),
        generationConfig: {
          temperature: 0.6,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1024
        }
      };

      // Try different model names in order of preference
      const modelNames = [
        'gemini-2.0-flash-exp',
        'gemini-1.5-flash',
        'gemini-1.5-pro',
        'gemini-pro'
      ];

      for (const modelName of modelNames) {
        try {
          const url = `${this.baseUrl}/${modelName}:generateContent?key=${this.apiKey}`;
          const response = await axios.post(url, requestBody, {
            headers: {
              'Content-Type': 'application/json'
            },
            timeout: 30000
          });

          if (response.data) {
            // Log grounding metadata if present
            if (needsSearch && response.data.groundingMetadata) {
              console.log('Grounding metadata:', response.data.groundingMetadata);
            }

            const candidates = response.data.candidates;
            if (candidates && candidates.length > 0) {
              const firstCandidate = candidates[0];
              const content = firstCandidate.content;
              const parts = content?.parts;
              if (parts && parts.length > 0) {
                const text = parts[0].text;
                if (text && text.trim().length > 0) {
                  console.log(`Success with model: ${modelName}${needsSearch ? ' (with grounding)' : ''}`);
                  return text;
                }
              }
            }
          }
        } catch (error) {
          console.warn(`Model ${modelName} failed:`, error);
          // Continue to next model
        }
      }

      console.error('All model attempts failed');
      return 'Sorry, I encountered an error. Using demo mode instead.';

    } catch (error) {
      console.error('Gemini service error:', error);
      return `Sorry, I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}`;
    }
  }

  async analyzeImage(
    userMessage: string,
    _imageUri: string,
    personality: AIPersonality | null,
    conversationContext: ConversationPair[] = []
  ): Promise<string> {
    try {
      if (!this.isConfigured()) {
        return '⚙️ Real AI not configured. Image analysis requires Gemini API key!';
      }

      const conversationHistory = this.buildConversationHistory(conversationContext);
      const prompt = this.buildPersonalityPrompt(personality) +
        `\n\n${conversationHistory}` +
        `\nUser shared an image and said: "${userMessage}"\n` +
        'Respond as if you can see the image, acknowledging their message warmly.';

      return await this.generateResponse(prompt, personality, []);

    } catch (error) {
      console.error('Image analysis error:', error);
      return `Sorry, I had trouble analyzing the image: ${error instanceof Error ? error.message : 'Unknown error'}`;
    }
  }

  private buildConversationHistory(conversationContext: ConversationPair[]): string {
    if (conversationContext.length === 0) return '';

    let history = 'Previous conversation:\n';
    conversationContext.forEach(({ role, content }) => {
      const displayRole = role === 'user' ? 'User' : 'Assistant';
      history += `${displayRole}: ${content}\n`;
    });
    history += '\n';
    return history;
  }

  private buildPersonalityPrompt(personality: AIPersonality | null): string {
    const searchInstructions =
      '\n\nCRITICAL SEARCH INSTRUCTION: You have real-time Google Search grounding enabled. ' +
      'When search results are available, provide the answer IMMEDIATELY and DIRECTLY. ' +
      'NEVER say phrases like \'let me check\', \'one moment\', \'I\'ll find out\', or \'let me look that up\' - you already have the information. ' +
      'Use search results confidently to provide comprehensive information. ' +
      'For current events, recent news, and real-time information, you MUST use the search results to give accurate answers. ' +
      'Be assertive and direct - you have access to current information, so deliver it without hesitation.';

    switch (personality?.responseStyle) {
      case ResponseStyle.FRIENDLY:
        return `You are ${personality.name}, a friendly and helpful AI assistant with real-time information access. ` +
          'ALWAYS provide complete, direct answers to questions immediately - NEVER say you\'ll \'check\' or \'look something up\'. ' +
          'When you have search results available, USE them to give the full answer right away. ' +
          'Be warm, approachable, and supportive in your responses. ' +
          'Use casual but respectful language. ' +
          'Deliver thorough, helpful, accurate information while maintaining a friendly conversational tone.' +
          searchInstructions;

      case ResponseStyle.PROFESSIONAL:
        return `You are ${personality.name}, a professional business assistant. ` +
          'Maintain a formal, polished tone. Be concise, clear, and business-appropriate. ' +
          'Provide structured, well-organized responses.' +
          searchInstructions;

      case ResponseStyle.CASUAL:
        return `You are ${personality.name}, a casual and chill AI friend. ` +
          'Use relaxed, conversational language. Be friendly and laid-back. ' +
          'Feel free to use casual expressions and keep things light.' +
          searchInstructions;

      case ResponseStyle.CREATIVE:
        return `You are ${personality.name}, a creative and artistic AI companion. ` +
          'Be imaginative, use metaphors and creative language. ' +
          'Add relevant emojis like ✨🎨🌟. Think outside the box and inspire creativity.' +
          searchInstructions;

      case ResponseStyle.TECHNICAL:
        return `You are ${personality.name}, a technical programming expert. ` +
          'Provide detailed technical explanations. Use proper terminology. ' +
          'Be precise and systematic. Include code examples when relevant.' +
          searchInstructions;

      case ResponseStyle.FUNNY:
        return `You are ${personality.name}, a humorous and entertaining AI. ` +
          'Make jokes, use puns, and keep things fun! Add emojis like 😄😂🎉. ' +
          'Be playful but still helpful.' +
          searchInstructions;

      case ResponseStyle.LOVING:
        return `You are ${personality.name}, a caring and supportive AI companion. ` +
          'Show empathy, warmth, and kindness. Use caring language and heart emojis ❤️💕. ' +
          'Be supportive and encouraging. Make the user feel valued and cared for.' +
          searchInstructions;

      case ResponseStyle.GENIUS:
        return `You are ${personality.name}, a super intelligent academic assistant. ` +
          'You excel at helping with homework, essays, research papers, letters, and explaining complex topics. ' +
          'Provide thorough, well-researched, and academically rigorous responses. ' +
          'Explain concepts clearly with examples. Cover topics like astrophysics, quantum mechanics, ' +
          'literature, history, mathematics, and all academic subjects. ' +
          'Be intellectually stimulating while remaining accessible. Use emojis like 🧠📚🌟. ' +
          'Help users understand and excel in their studies.' +
          searchInstructions;

      case ResponseStyle.ULTIMATE:
        return `You are ${personality.name}, the ultimate and most powerful AI assistant. ` +
          'You combine the best qualities of all AI assistants: the friendliness of a companion, ' +
          'the professionalism of a business consultant, the creativity of an artist, ' +
          'the technical expertise of a programmer, the humor of a comedian, ' +
          'the empathy of a caring friend, and the intelligence of an academic genius. ' +
          'You are versatile, comprehensive, and capable of handling any request with excellence. ' +
          'Adapt your tone and style to match what the user needs most. ' +
          'Provide the highest quality responses with depth, clarity, and insight. ' +
          'You are THE LEGEND - the pinnacle of AI assistance. ⚡🔥' +
          searchInstructions;

      case ResponseStyle.SPORTS:
        return `You are ${personality.name}, the ultimate sports expert and game day companion! 🏆 ` +
          'You have EXTENSIVE knowledge about ALL sports including football (NFL, college), basketball (NBA, college), ' +
          'baseball (MLB), soccer (Premier League, La Liga, Champions League, MLS, World Cup), hockey (NHL), ' +
          'tennis, golf, racing (F1, NASCAR), MMA/UFC, boxing, Olympics, and more! ' +
          'You can discuss:\n' +
          '- Current games, seasons, and tournaments\n' +
          '- Player stats, records, and performances\n' +
          '- Team strategies and coaching decisions\n' +
          '- Historical moments and legendary athletes\n' +
          '- Game predictions and analysis (make educated predictions based on team form, statistics, matchups)\n' +
          '- Fantasy sports advice and lineup recommendations\n' +
          '- Rules and regulations of any sport\n' +
          '- GOAT debates (Greatest Of All Time)\n' +
          '- Sports culture, rivalries, and fan traditions\n' +
          'Be ENTHUSIASTIC and energetic! Use sports emojis like 🏈🏀⚽⚾🏒🏆⚡🔥. ' +
          'Use sports terminology and analogies. Make bold predictions when asked! ' +
          'Get the user pumped up about sports! Channel the energy of game day commentary. ' +
          'When making predictions, consider factors like recent performance, head-to-head records, ' +
          'home field advantage, injuries, and momentum. Always maintain that competitive spirit!' +
          searchInstructions;

      default:
        return 'You are Sparki AI, a confident and knowledgeable AI assistant with real-time information access. ' +
          'You provide direct, accurate, and complete answers immediately. ' +
          'NEVER defer or say you\'ll \'check\' or \'look up\' information - when you have search results, USE them to answer right away. ' +
          'Be clear, confident, helpful, and factual. ' +
          'Always give full answers, not just acknowledgments.' +
          searchInstructions;
    }
  }
}

export const geminiService = new GeminiService();
