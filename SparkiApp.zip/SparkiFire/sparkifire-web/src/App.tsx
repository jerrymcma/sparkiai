import { ChatScreen } from './app/ChatScreen';

function App() {
  return <ChatScreen />;
}

export default App;
