import { create } from 'zustand';
import { Message, AIPersonality, MessageType } from '../types';
import { personalities } from '../data/personalities';
import { geminiService } from '../services/geminiService';
import { storageService } from '../services/storageService';

interface ChatState {
  messages: Message[];
  isLoading: boolean;
  currentPersonality: AIPersonality;
  isListening: boolean;
  isSpeaking: boolean;
  
  // Actions
  sendMessage: (content: string, imageUri?: string, messageType?: MessageType) => Promise<void>;
  changePersonality: (personality: AIPersonality) => void;
  clearMessages: () => void;
  startFresh: () => void;
  setIsListening: (isListening: boolean) => void;
  setIsSpeaking: (isSpeaking: boolean) => void;
  initialize: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  isLoading: false,
  currentPersonality: personalities.DEFAULT,
  isListening: false,
  isSpeaking: false,

  initialize: () => {
    const { currentPersonality } = get();
    const savedMessages = storageService.loadMessages(currentPersonality.id);
    
    // Check for auto-reset
    if (storageService.shouldAutoReset(currentPersonality.id)) {
      storageService.clearMessages(currentPersonality.id);
      const autoResetMessage: Message = {
        id: crypto.randomUUID(),
        content: '🔄 Starting fresh! Previous conversation was automatically reset.',
        isFromUser: false,
        timestamp: Date.now(),
        messageType: MessageType.TEXT,
        personalityId: currentPersonality.id
      };
      set({ messages: [autoResetMessage] });
      storageService.saveMessages(currentPersonality.id, [autoResetMessage]);
    } else if (savedMessages.length > 0) {
      set({ messages: savedMessages });
    } else {
      // Add greeting if no messages
      const greetingMessage: Message = {
        id: crypto.randomUUID(),
        content: currentPersonality.greeting,
        isFromUser: false,
        timestamp: Date.now(),
        messageType: MessageType.TEXT,
        personalityId: currentPersonality.id
      };
      set({ messages: [greetingMessage] });
      storageService.saveMessages(currentPersonality.id, [greetingMessage]);
    }
  },

  sendMessage: async (content: string, imageUri?: string, messageType = MessageType.TEXT) => {
    const { currentPersonality, isLoading } = get();
    
    if ((content.trim().length === 0 && !imageUri) || isLoading) {
      return;
    }

    // Check for auto-reset before sending
    if (storageService.shouldAutoReset(currentPersonality.id)) {
      storageService.clearMessages(currentPersonality.id);
      const autoResetMessage: Message = {
        id: crypto.randomUUID(),
        content: '🔄 Starting fresh! Previous conversation was automatically reset.',
        isFromUser: false,
        timestamp: Date.now(),
        messageType: MessageType.TEXT,
        personalityId: currentPersonality.id
      };
      set({ messages: [autoResetMessage] });
      storageService.saveMessages(currentPersonality.id, [autoResetMessage]);
    }

    // Add user message
    const userMessage: Message = {
      id: crypto.randomUUID(),
      content,
      isFromUser: true,
      timestamp: Date.now(),
      imageUri,
      messageType,
      personalityId: currentPersonality.id
    };

    const updatedMessages = [...get().messages, userMessage];
    set({ messages: updatedMessages, isLoading: true });
    storageService.saveMessages(currentPersonality.id, updatedMessages);

    try {
      // Get conversation context
      const conversationContext = storageService.getConversationContext(currentPersonality.id);

      // Get AI response
      let aiResponse: string;
      if (messageType === MessageType.IMAGE || messageType === MessageType.TEXT_WITH_IMAGE) {
        aiResponse = await geminiService.analyzeImage(
          content,
          imageUri || '',
          currentPersonality,
          conversationContext
        );
      } else {
        aiResponse = await geminiService.generateResponse(
          content,
          currentPersonality,
          conversationContext
        );
      }

      // Add AI message
      const aiMessage: Message = {
        id: crypto.randomUUID(),
        content: aiResponse,
        isFromUser: false,
        timestamp: Date.now(),
        messageType: MessageType.TEXT,
        personalityId: currentPersonality.id
      };

      const finalMessages = [...updatedMessages, aiMessage];
      set({ messages: finalMessages, isLoading: false });
      storageService.saveMessages(currentPersonality.id, finalMessages);

    } catch (error) {
      console.error('Error getting AI response:', error);
      const errorMessage: Message = {
        id: crypto.randomUUID(),
        content: 'Sorry, I encountered an error while processing your request. Please try again.',
        isFromUser: false,
        timestamp: Date.now(),
        messageType: MessageType.TEXT,
        personalityId: currentPersonality.id
      };

      const finalMessages = [...updatedMessages, errorMessage];
      set({ messages: finalMessages, isLoading: false });
      storageService.saveMessages(currentPersonality.id, finalMessages);
    }
  },

  changePersonality: (personality: AIPersonality) => {
    const { currentPersonality } = get();
    const messages = get().messages;
    
    // Save current conversation
    storageService.saveMessages(currentPersonality.id, messages);

    // Load new personality's conversation
    const savedMessages = storageService.loadMessages(personality.id);
    
    if (savedMessages.length > 0) {
      set({ currentPersonality: personality, messages: savedMessages });
    } else {
      // Add greeting for new personality
      const greetingMessage: Message = {
        id: crypto.randomUUID(),
        content: personality.greeting,
        isFromUser: false,
        timestamp: Date.now(),
        messageType: MessageType.TEXT,
        personalityId: personality.id
      };
      set({ currentPersonality: personality, messages: [greetingMessage] });
      storageService.saveMessages(personality.id, [greetingMessage]);
    }
  },

  clearMessages: () => {
    const { currentPersonality } = get();
    storageService.clearMessages(currentPersonality.id);
    set({ messages: [] });
  },

  startFresh: () => {
    const { currentPersonality } = get();
    storageService.clearMessages(currentPersonality.id);
    
    const greetingMessage: Message = {
      id: crypto.randomUUID(),
      content: currentPersonality.greeting,
      isFromUser: false,
      timestamp: Date.now(),
      messageType: MessageType.TEXT,
      personalityId: currentPersonality.id
    };
    
    set({ messages: [greetingMessage] });
    storageService.saveMessages(currentPersonality.id, [greetingMessage]);
  },

  setIsListening: (isListening: boolean) => {
    set({ isListening });
  },

  setIsSpeaking: (isSpeaking: boolean) => {
    set({ isSpeaking });
  }
}));
